# Rover

Raspberry Pi / ROS 2 packages, perception, mapping and mission supervision.

Status: project hardware/source files have not yet been imported. Preserve the working versions when adding them.
