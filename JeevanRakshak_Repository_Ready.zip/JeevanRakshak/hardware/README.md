# Hardware

Wiring, bill of materials, encoder specifications and mechanical drawings.

Status: project hardware/source files have not yet been imported. Preserve the working versions when adding them.
