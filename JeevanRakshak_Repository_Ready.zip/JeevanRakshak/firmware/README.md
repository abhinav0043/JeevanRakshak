# Firmware

ESP32 motor control, rear encoder acquisition and worker wearable firmware.

Status: project hardware/source files have not yet been imported. Preserve the working versions when adding them.
