# JeevanRakshak — Underground Rescue Command Center

A runnable, local-first React + FastAPI application for R01 rover supervision, worker wearables, mine reconstruction and relay recovery. **Starts in clearly labeled DEMO MODE.** The packaged frontend is prebuilt; no Node.js is needed simply to run the release.

## Quick start — Windows base-station laptop

1. Extract this whole ZIP to a writable folder, for example C:\JeevanRakshak.
2. Install Python 3.10+ if missing. Enable **Add Python to PATH**.
3. Double-click **start-jeevanrakshak.bat**.

The launcher creates a Python virtual environment, installs backend packages on first run, starts the backend and opens **http://127.0.0.1:8000**. The same server serves the prebuilt frontend and WebSocket feed. Keep the terminal open; Ctrl+C stops the service. First-time dependency installation needs internet; after setup, application operation is offline. The release uses no CDN, external fonts, cloud API, map tile server or hosted inference.

Linux/macOS: `bash start-jeevanrakshak.sh` (Python 3.10+ and the OS Python venv package required).

If port 8000 is occupied, stop the existing service first. Do not launch two instances on one database.

## Demonstrate immediately

- R01 moves and the synthetic point cloud progressively appears.
- Open **Scenario controls** in the bottom dock for individual incidents.
- **Play** runs FULL RESCUE DEMO, one step every four seconds.
- **Pause** pauses the scripted scenario, not onboard-like telemetry; **Step** advances one event.
- The global **Pause autonomy** command stops simulated motion and recovery.
- The 20-step scenario includes gas detection, route change, possible victim, thermal correlation, W04 SOS, failed R2–R3 link, relay deployment, wireless bypass and event synchronization.
- **Reset** archives the current session and creates a fresh demonstration.
- On **Network & recovery**, trigger NETWORK BREAK then START NETWORK RECOVERY to see timed eight-stage recovery.
- **Present** hides the demo dock and expands visualizations. DEMO MODE remains visible.
- Click a worker ID for charts. **Focus on worker** frames the known relay zone, not a precise worker point.
- Use the 3D / 2D toggle, Orbit / Top / Follow / Rover cameras, zoom, pan and fullscreen.
- Global commands require confirmation. Emergency STOP latches; **R01 rover → Clear stop latch**, then **Resume autonomy** is required to move again.
- Acknowledging an alert records awareness; it does not clear the underlying hazard.

## Implemented

- React 19, TypeScript, Vite, Tailwind CSS, React Router, Recharts, Three.js / React Three Fiber.
- Dark responsive dashboard; dedicated map, rover, workers, network, environment, incidents, timeline and configuration screens.
- Reusable 3D buffers, metric geometry, rover heading, planned/travelled/return paths, frontier, blocked branch and semantic markers; SVG tactical fallback if WebGL fails.
- Synthetic camera/depth diagnostic frames, detection overlays and AMG8833 8×8 thermal grid with optional interpolation.
- AI observations and deterministic mission-state explanations, explicitly simulated in demo.
- Six workers, vitals and exposure charts, SOS/fall incidents, last confirmed zones, stale-packet indicators.
- Interactive relay topology and bypass recovery, payload count, broadband / LoRa communication panels.
- Full rescue scenario plus individual simulation triggers.
- REST + WebSocket live state, reconnect snapshots, typed Pydantic contracts, bounded histories and point cloud retention.
- SQLite WAL database with sessions, event records, snapshots, alerts, telemetry, health, actions and JSON/CSV export.
- Session history remains available after restart. Startup creates a new session; it does not silently resume a previous mission.
- Hardware-mode ingestion with strict demo/real separation, optional ingestion token, LoRa parser and provider interfaces.
- Hardware commands fail explicitly until a real transport adapter is installed. An accepted simulated command never implies hardware actuation.

## Architecture boundary

**Real perception, navigation, hazard responses, victim investigation, communication-loss policy, relay deployment decisions and motor control execute on R01.**

This base application visualizes and stores published decisions and sends operator requests through a future CommandProvider. It does not run real Nav2 or replace R01 autonomy. The simulation module emulates rover events for presentation only and is disabled in hardware mode.

Geometry is sensor-derived in hardware mode. AI annotates geometry; it does not invent it. Demo geometry is a procedural test fixture. Workers have checkpoints/relay zones, not invented GPS. MQ values are raw uncalibrated ADC counts, not certified gas concentration measurements.

## Source tree

```
JeevanRakshak/
├── start-jeevanrakshak.bat
├── start-jeevanrakshak.sh
├── README.md
├── INTEGRATION.md
├── VALIDATION.md
├── scripts/start.py
├── schemas/openapi.json
├── backend/
│   ├── requirements.txt
│   ├── .env.example
│   ├── app/
│   │   ├── main.py              # REST, WebSocket, ingestion and static hosting
│   │   ├── models.py            # Pydantic telemetry / command schemas
│   │   ├── database.py          # SQLite events, sessions and snapshots
│   │   ├── simulation.py        # Demo-only deterministic scenario
│   │   ├── services/state.py    # Normalized state and event publication
│   │   └── providers/
│   │       ├── base.py          # Hardware interfaces and explicit placeholders
│   │       ├── mock.py          # Procedural mock data providers
│   │       └── lora.py          # Actual wearable packet parser
│   └── tests/test_system.py
└── frontend/
    ├── package.json / package-lock.json
    ├── vite.config.ts / tsconfig.json / index.html
    ├── dist/                   # Prebuilt offline frontend
    └── src/
        ├── App.tsx             # Shell, routes and operator workflows
        ├── main.tsx / style.css
        ├── types/index.ts
        ├── services/live.tsx    # REST client, WebSocket reconnection, chart buffers
        └── components/
            ├── Twin.tsx
            ├── Network.tsx
            ├── Monitoring.tsx
            └── Common.tsx
```

## Development commands

Python 3.10+, Node.js 20.19+ or 22.12+, npm. From the extracted project folder:

Windows PowerShell:
```powershell
py -3 -m venv .venv
.\.venv\Scripts\python -m pip install -r backend\requirements.txt
cd frontend
npm ci
npm run dev
```
In a second terminal from the project root:
```powershell
cd backend
..\.venv\Scripts\python -m uvicorn app.main:app --host 127.0.0.1 --port 8000 --reload
```
Development UI: **http://127.0.0.1:5173**. Vite proxies /api and /ws to port 8000. Backend docs: **http://127.0.0.1:8000/docs**.

Linux/macOS equivalents:
```bash
python3 -m venv .venv
.venv/bin/pip install -r backend/requirements.txt
cd frontend && npm ci && npm run dev
# Separate terminal, project root:
cd backend
../.venv/bin/python -m uvicorn app.main:app --host 127.0.0.1 --port 8000 --reload
```

Build after frontend changes:
```bash
cd frontend
npm run build
```
Restart the backend if it was started before dist existed.

Tests:
```powershell
cd backend
..\.venv\Scripts\python -m pytest -q
```
Linux: `cd backend && ../.venv/bin/python -m pytest -q`.

## Data and integration

SQLite is created at **backend/data/missions.sqlite3**. Set JR_DB to override. Back up the database while the app is stopped. Session exports are available on Mission timeline. Graphs show the last 120 received samples; event exports contain persisted history, not only that in-memory chart window.

See **INTEGRATION.md** for API routes, examples, binary point clouds, frame conversion, authentication and hardware adapter work.

## Genuinely unfinished hardware work

- ROS 2 topic subscriptions, Pi bridge deployment, serial LoRa receiver wiring and live network probes are intentionally not connected.
- Real command transport and rover acknowledgements are not implemented; hardware commands return HTTP 503 instead of pretending success.
- Real AI models, class training/validation, SLAM/RTAB-Map processing, Nav2 and ESP32 control are outside the base-station application and must run on R01.
- Camera mock uses a clearly labeled synthetic diagnostic scene. No recorded mine footage is bundled. MJPEG and browser-supported video URLs work; RTSP conversion and WebRTC signaling need a local gateway.
- Video recording is not implemented; UI explicitly says NOT RECORDING.
- Demo recovery visually simulates deployment and verification; it does not physically deploy a node or validate RF connectivity.
- No safety certification, precise wearable tracking, medical diagnosis, collapse prediction or real sensor calibration is claimed.
- Loopback use is the supported default. For shared operator access, add authentication/authorization and transport security before exposing control APIs on a network.
