# Hardware integration contract

## Data path and responsibility

R01 sensors → R01 SLAM/perception/mission supervisor → normalization bridge → base ingestion → SQLite + WebSocket → existing UI.

R01 retains its mission state, command validation, watchdog, deployment and communication-loss policy. The base never computes real motor outputs or autonomously decides to move the rover.

Local launch binds to 127.0.0.1. A bridge on the base can collect Pi / ROS / serial packets and POST to this local service. For direct LAN ingestion, explicitly bind to the base LAN address, set a long JR_INGEST_TOKEN, constrain firewall access, and add operator authentication before exposing UI commands. The optional token protects ingestion only; it is not an operator authorization system.

PowerShell environment:
```powershell
$env:JR_INGEST_TOKEN="replace-with-a-long-random-token"
```
The .env.example is documentation only; the launcher does not silently load it.

## Switching modes

Click DEMO MODE in the header and confirm. The previous session is archived, all live state is cleared, and REAL HARDWARE MODE starts with missing-data views. Demo endpoints return 409 in real mode; ingestion returns 409 in demo mode. Real commands return 503 until CommandProvider is replaced.

Data timestamps are ISO 8601 UTC strings. Adapters must send actual observation timestamps, not re-label old data as fresh. The frontend labels data stale after 10 seconds. A connected WebSocket does not establish R01 health.

## REST routes

| Route | Payload / purpose |
|---|---|
| GET /api/state | Complete current normalized snapshot |
| GET /api/health | Base process health, not rover health |
| POST /api/mode | {"mode":"DEMO"} or {"mode":"REAL"} |
| POST /api/demo | {"action":"PLAY"} etc.; demo only |
| POST /api/commands | Command + explicit confirmation for sensitive actions |
| POST /api/ingest/rover | Rover model: actual pose, battery, velocity, mode, subsystem state |
| POST /api/ingest/workers/W01 | Worker packet model; path ID must match body |
| POST /api/ingest/lora | Raw packet plus independently observed checkpoint metadata |
| POST /api/ingest/environment | {"readings":{name: Reading}} |
| POST /api/ingest/thermal | timestamp, exactly 64 values, ambient, interpretation, confidence |
| POST /api/ingest/ai | Detection with trained class, confidence, bounding box and range |
| POST /api/ingest/ai/assessment | R01 mission reasoning, observations, action, next check |
| POST /api/ingest/network | Full node/link topology and recovery state from R01/network probes |
| POST /api/ingest/video | Browser-compatible local URLs and measured depth ranges |
| POST /api/ingest/map/pose | Position in map frame, after rover model received |
| POST /api/ingest/map/path | points, frame_id, kind: planned/trail/return_path/frontier |
| POST /api/ingest/map/markers | Upsert persistent semantic marker by ID |
| POST /api/ingest/map/occupancy | width, height, resolution, origin, cells [-1,100] |
| POST /api/ingest/map/pointcloud | JSON XYZ batch |
| POST /api/ingest/map/pointcloud/binary | Efficient float32 XYZ batch |
| POST /api/missions/start, /end | Recording lifecycle; does not stop a real rover |
| GET /api/missions | Session list |
| GET /api/missions/{id} | Saved snapshot |
| GET /api/history?mission=ID&type=worker.telemetry&limit=500 | Persistent event history |
| GET /api/export?mission=ID&format=json or csv | Download events |

The full generated OpenAPI contract is in schemas/openapi.json and at http://127.0.0.1:8000/docs.

## Wearable example

Existing packet preserved:
```text
W01,HR=82,SPO2=97,TEMP=28.4,HUM=67,MQ4=230,MQ135=180,FALL=0,SOS=0,STATE=NORMAL
```

POST /api/ingest/lora:
```json
{
  "packet":"W01,HR=82,SPO2=97,TEMP=28.4,HUM=67,MQ4=230,MQ135=180,FALL=0,SOS=0,STATE=NORMAL",
  "last_checkpoint":"CP-04",
  "zone_start_relay":"R3",
  "zone_end_relay":"R4",
  "rssi":-78
}
```
Do not infer a checkpoint or exact position merely from an RSSI value. Omit unavailable metadata. SOS/fall forces EMERGENCY even if the transmitted state is inconsistent.

Python bridge example (stdlib only):
```python
import json, urllib.request
payload = {
    "packet": "W01,HR=82,SPO2=97,TEMP=28.4,HUM=67,MQ4=230,MQ135=180,FALL=0,SOS=0,STATE=NORMAL"
}
req = urllib.request.Request(
    "http://127.0.0.1:8000/api/ingest/lora",
    data=json.dumps(payload).encode(),
    headers={"Content-Type": "application/json", "X-JR-Token": "YOUR_TOKEN"},
    method="POST",
)
with urllib.request.urlopen(req, timeout=2) as response:
    print(response.read().decode())
```

## Coordinates and geometry

UI uses meters, X/Z horizontal, Y up; orientation is yaw in radians in the UI horizontal plane. Convert ROS REP-103 map coordinates (X forward, Y left, Z up) consistently at the adapter:
UI x = ROS x; UI y = ROS z; UI z = -ROS y; UI yaw = -ROS yaw.
Convert every pose, point cloud, path and semantic marker with the same frame transform. Do not mix transforms. Include frame_id="map". Transform ROS quaternion orientation into yaw before sending.

The demo has lightweight tunnel scaffold geometry. Real mode clears it and renders incoming cloud/path/marker data; it never substitutes the demo tunnel if a map is missing. The occupancy ingestion route accepts up to 512×512 cells; the 2D view projects occupied cells, point cloud, routes and markers. RTAB-Map mesh decoding remains bridge work.

JSON point-cloud example:
```json
{"frame_id":"map","sequence":1,"replace":true,"xyz":[0,0,0,1,0,0,1,1,0]}
```
Up to 50,000 points per batch. Binary: little-endian float32 interleaved x,y,z; Content-Type application/octet-stream; sequence and replace query parameters. Max 600,000 bytes. Retains at most 100,000 points in the live view; batch metadata and bounded cloud snapshots are persisted. Downsample on R01 for the available bandwidth. This is a visualization stream, not a raw LiDAR archive.

## WebSocket

Connect to ws://127.0.0.1:8000/ws/live. Initial message is system.snapshot. Subsequent messages use event.batch whose payload contains typed envelopes and a bounded current-state snapshot. Unchanged cloud arrays are omitted from subsequent snapshots; keep the previous cloud for the same mission. A changed mission with no cloud clears the view. Clients should tolerate unknown event types. Every envelope has type, timestamp, source, data_mode and payload.

Examples: rover.telemetry, worker.telemetry, worker.emergency, environment.telemetry, thermal.telemetry, ai.detection, ai.assessment, mission.state, navigation.path, map.pose, map.pointcloud, map.marker, network.topology, network.failure, network.recovery, relay.deployment, system.health, alert.created, command.requested.

Frontend reconnects with exponential backoff capped at 10 seconds. Reconnect receives a complete current state; historical events remain available through REST. Slow clients are dropped from broadcast to avoid blocking others.

## Video

- MJPEG uses an img stream.
- VIDEO uses the browser's video element for supported files/streams.
- WEBRTC_GATEWAY is a declared integration placeholder; implement signaling/track attachment before selecting it.
- RTSP is not directly browser-playable. Convert it locally using a suitable gateway.
- RGB and depth source URLs are independent. Bounding boxes are normalized [x,y,width,height] in [0,1].
- Record actual trained model classes in the assessment. Do not label unsupported detections as real.
- The thermal confidence and human-signature statement are interpretations, not sensor truth or medical conclusions.

## Provider extension points

backend/app/providers/base.py declares RoverTelemetryProvider, WorkerTelemetryProvider, MapProvider, PointCloudProvider, VideoProvider, AIInferenceProvider, ThermalProvider, NetworkTopologyProvider and CommandProvider.

Ros2RoverProvider, Ros2MapProvider, PiAIProvider and RealNetworkProvider intentionally raise NotImplementedError. Implement their event streams in a bridge or POST normalized observations to ingestion. The LoRaWorkerProvider packet parser is functional.

Replace UnconfiguredCommandProvider with a transport that sends an idempotent command request to R01 and waits for a rover ACK/rejection. Add command IDs, expiry, retry limits, device identity, authentication and audit fields when wiring hardware. R01 must reject stale/unsafe requests locally. Base display acknowledgement must not be treated as proof of motor state.

## Local deployment limits

One FastAPI process / worker owns the normalized state. Do not use multiple uvicorn workers without a shared-state redesign. SQLite writes are local, and the event table grows until sessions are archived externally. No automatic destructive retention policy is imposed. The base stream and history continue independently of frontend browser tabs.
