import os, tempfile, json, struct
os.environ['JR_DB']=tempfile.mktemp(suffix='.sqlite3')
from fastapi.testclient import TestClient
from app.main import app,state,sim,db
from app.providers.lora import LoRaWorkerProvider

def reset(c):assert c.post('/api/mode',json={'mode':'DEMO'}).status_code==200
def test_full_scenario_and_persistence():
    with TestClient(app) as c:
        reset(c)
        for _ in range(20):assert c.post('/api/demo',json={'action':'STEP'}).status_code==200
        s=c.get('/api/state').json()
        assert s['scenario']['step']==20
        assert s['network']['status']=='BYPASS ACTIVE'
        assert s['rover']['relay_nodes_remaining']==2
        assert s['workers'][3]['sos']
        assert any(m['type']=='VICTIM' for m in s['map']['markers'])
        assert any(m['type']=='GAS_HAZARD' for m in s['map']['markers'])
        assert all(m['position'] is None for m in s['map']['markers'] if m['type']=='WORKER_ZONE')
        id=s['mission_id'];c.post('/api/missions/end')
        assert c.get('/api/missions/'+id).json()['scenario']['step']==20
        assert 'network.recovery' in c.get('/api/export?mission='+id).text
        assert c.get('/api/export?format=csv').text.startswith('id,mission')
def test_stop_latch_and_confirmation():
    with TestClient(app) as c:
        reset(c)
        assert c.post('/api/commands',json={'action':'STOP'}).status_code==400
        assert c.post('/api/commands',json={'action':'STOP','confirmed':True}).status_code==200
        pos=dict(state.data['rover']['position']);sim.tick()
        assert state.data['rover']['position']==pos
        assert c.post('/api/demo',json={'action':'STEP'}).status_code==409
        assert c.post('/api/commands',json={'action':'RESUME','confirmed':True}).status_code==409
        assert c.post('/api/commands',json={'action':'ALL_CLEAR','confirmed':True}).status_code==200
        assert state.data['rover']['mission_state']=='READY'
def test_mode_isolation_and_ingest():
    with TestClient(app) as c:
        reset(c)
        packet={'worker_id':'W01','heart_rate':83,'spo2':97,'sos':True}
        assert c.post('/api/ingest/workers/W01',json=packet).status_code==409
        c.post('/api/mode',json={'mode':'REAL'})
        s=c.get('/api/state').json()
        assert s['rover'] is None and not s['workers'] and not s['map']['cloud']
        assert c.post('/api/demo',json={'action':'PLAY'}).status_code==409
        assert c.post('/api/ingest/workers/W01',json=packet).status_code==200
        assert state.data['workers'][0]['state']=='EMERGENCY'
        assert c.post('/api/commands',json={'action':'STOP','confirmed':True}).status_code==503
        assert c.post('/api/ingest/workers/W02',json=packet).status_code==422
        assert c.post('/api/ingest/thermal',json={'values':[1],'ambient':1}).status_code==422
def test_acknowledgement_and_payload_limits():
    with TestClient(app) as c:
        reset(c);c.post('/api/demo',json={'action':'WORKER_SOS'})
        id=state.data['alerts'][0]['id']
        assert c.post('/api/commands',json={'action':'ACKNOWLEDGE_ALERT','alert_id':id}).status_code==200
        assert state.data['alerts'][0]['acknowledged']
        for _ in range(3):assert c.post('/api/commands',json={'action':'DEPLOY_RELAY','confirmed':True}).status_code==200
        assert c.post('/api/commands',json={'action':'DEPLOY_RELAY','confirmed':True}).status_code==409
def test_lora_and_binary_cloud():
    w=LoRaWorkerProvider.parse('W01,HR=82,SPO2=97,TEMP=28.4,HUM=67,MQ4=230,MQ135=180,FALL=1,SOS=0,STATE=NORMAL')
    assert w.state=='EMERGENCY' and w.zone_start_relay is None
    with TestClient(app) as c:
        c.post('/api/mode',json={'mode':'REAL'})
        assert c.post('/api/ingest/map/pointcloud/binary?replace=true',content=struct.pack('<6f',1,2,3,4,5,6)).status_code==200
        assert state.data['map']['cloud']==[1,2,3,4,5,6]
        assert c.post('/api/ingest/map/pointcloud',json={'sequence':2,'xyz':[1,2]}).status_code==422
def test_websocket_reconnect_snapshot():
    with TestClient(app) as c:
        reset(c)
        with c.websocket_connect('/ws/live') as ws:
            msg=ws.receive_json();assert msg['type']=='system.snapshot';assert msg['data_mode']=='DEMO'
        c.post('/api/demo',json={'action':'GAS_LEAK'})
        with c.websocket_connect('/ws/live') as ws:assert ws.receive_json()['payload']['environment']['Methane']['severity']=='WARNING'
def test_goal_navigation():
    with TestClient(app) as c:
        reset(c)
        assert c.post('/api/commands',json={'action':'NAVIGATE_TO','confirmed':True,'goal':{'x':8.3,'y':0,'z':0}}).status_code==200
        for _ in range(5):sim.tick()
        assert state.data['rover']['mission_state']=='READY'
        assert state.data['rover']['position']['x']==8.3
def test_ingest_token(monkeypatch):
    with TestClient(app) as c:
        c.post('/api/mode',json={'mode':'REAL'});monkeypatch.setenv('JR_INGEST_TOKEN','test-local-token')
        assert c.post('/api/ingest/rover',json={}).status_code==401
        assert c.post('/api/ingest/rover',json={},headers={'X-JR-Token':'test-local-token'}).status_code==422
def test_occupancy_and_timestamp_validation():
    with TestClient(app) as c:
        c.post('/api/mode',json={'mode':'REAL'})
        payload={'width':2,'height':2,'resolution':.1,'origin':{'x':0,'y':0,'z':0},'cells':[0,100,-1,50]}
        assert c.post('/api/ingest/map/occupancy',json=payload).status_code==200
        payload['cells']=[0]
        assert c.post('/api/ingest/map/occupancy',json=payload).status_code==422
        assert c.post('/api/ingest/workers/W01',json={'worker_id':'W01','last_seen':'invalid'}).status_code==422
