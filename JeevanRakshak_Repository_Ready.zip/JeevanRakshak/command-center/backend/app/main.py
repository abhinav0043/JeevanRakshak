import asyncio, contextlib, os, json, csv, io, struct
from contextlib import asynccontextmanager
from pathlib import Path as FilePath
from fastapi import FastAPI, WebSocket, WebSocketDisconnect, HTTPException, Depends, Header, Request
from fastapi.responses import Response, FileResponse
from fastapi.staticfiles import StaticFiles
from .models import *
from .database import Database
from .services.state import State
from .simulation import Simulation, STEPS, RECOVERY
from .providers.base import UnconfiguredCommandProvider
from .providers.lora import LoRaWorkerProvider

db=Database();state=State(db);sim=Simulation(state);commands=UnconfiguredCommandProvider()
last_cloud=None
async def broadcast():
    global last_cloud
    snapshot=state.snapshot()
    # Static cloud arrays need not cross WebSocket on every telemetry tick.
    cloud_identity=(snapshot['mission_id'], state.cloud_revision)
    if cloud_identity==last_cloud:
        snapshot['map'].pop('cloud',None)
    last_cloud=cloud_identity
    pending=state.pending[:];state.pending.clear()
    packet=Event(type='system.snapshot',source='BASE',data_mode=snapshot['data_mode'],payload=snapshot).model_dump()
    async def send(ws):
        try:
            # Full bounded snapshot recovers dropped events; pointcloud has a separate batch route.
            await asyncio.wait_for(ws.send_json({'type':'event.batch','timestamp':now(),'data_mode':snapshot['data_mode'],'source':'BASE','payload':pending+[packet]}),2)
        except Exception:state.clients.discard(ws)
    if state.clients:await asyncio.gather(*(send(ws) for ws in list(state.clients)))
async def loop():
    counter=0
    while True:
        sim.tick();await broadcast();counter+=1
        if counter%10==0:db.save(state.data['mission_id'],state.data)
        await asyncio.sleep(1)
@asynccontextmanager
async def lifespan(app):
    task=asyncio.create_task(loop())
    yield
    task.cancel()
    with contextlib.suppress(asyncio.CancelledError):await task
    db.save(state.data['mission_id'],state.data);db.end(state.data['mission_id'])
app=FastAPI(title='JeevanRakshak Local Command Center',version='1.0.0',lifespan=lifespan)

@app.middleware('http')
async def local_origin(request:Request,call_next):
    origin=request.headers.get('origin')
    if origin:
        from urllib.parse import urlparse
        host=urlparse(origin).hostname
        if host not in ('127.0.0.1','localhost',request.url.hostname):
            return Response('Origin not permitted',status_code=403)
    return await call_next(request)
def real(x_jr_token: str | None=Header(default=None)):
    if state.data['data_mode']!='REAL':raise HTTPException(409,'Switch to REAL HARDWARE MODE before ingesting; demo and real data cannot mix')
    token=os.getenv('JR_INGEST_TOKEN')
    if token and x_jr_token!=token:raise HTTPException(401,'Invalid ingestion token')
def active():
    if not state.data['mission_active']:raise HTTPException(409,'Start a new mission first')
def put(key,value,type):
    state.data[key]=value;state.emit(type,value);return {'accepted':True,'data_mode':'REAL'}
@app.get('/api/state')
def get_state():return state.snapshot()
@app.get('/api/health')
def health():return {'status':'ok','mode':state.data['data_mode'],'command_transport':'UNCONFIGURED'}
@app.get('/api/scenario')
def scenario():return {'steps':STEPS,'recovery':RECOVERY}
@app.post('/api/mode')
async def mode(req:ModeRequest):
    state.reset(req.mode);sim.reset();await broadcast();return state.snapshot()
@app.post('/api/demo')
async def demo(req:DemoRequest):
    if state.data['data_mode']!='DEMO':raise HTTPException(409,'Simulation disabled in hardware mode')
    active()
    if state.data['stop_latched'] and req.action not in ['RESET','PAUSE']:raise HTTPException(409,'Emergency stop latched; confirm ALL_CLEAR or reset demo')
    if req.action=='DEPLOY_RELAY' and state.data['rover']['relay_nodes_remaining']==0:raise HTTPException(409,'No relay nodes remaining')
    sim.act(req.action);await broadcast();return {'accepted':True}
@app.post('/api/commands')
async def command(req:Command):
    active()
    if req.action!='ACKNOWLEDGE_ALERT' and not req.confirmed:raise HTTPException(400,'Explicit operator confirmation required')
    if req.action=='NAVIGATE_TO' and req.goal is None:raise HTTPException(422,'Goal is required')
    if req.action=='ACKNOWLEDGE_ALERT':
        alert=next((a for a in state.data['alerts'] if a['id']==req.alert_id),None)
        if not alert:raise HTTPException(404,'Alert not found')
        alert['acknowledged']=True;state.emit('alert.acknowledged',alert,'BASE')
    elif state.data['data_mode']=='REAL':
        state.emit('command.requested',req.model_dump(),'BASE')
        try:result=await commands.send(req)
        except RuntimeError as e:
            state.log('SYSTEM','Command rejected: '+str(e),'WARNING');raise HTTPException(503,str(e))
        return result
    else:
        r=state.data['rover']
        if state.data['stop_latched'] and req.action not in ['STOP','ALL_CLEAR']:raise HTTPException(409,'Stop is latched; ALL_CLEAR required')
        if req.action=='STOP':
            state.data['stop_latched']=True;state.data['scenario']['playing']=False;sim.recovering=False
            sim.decision('SAFE STOP','Operator emergency stop','Stop latched','Motors disabled in simulation');r['velocity_linear']=0
        elif req.action=='ALL_CLEAR':
            state.data['stop_latched']=False;sim.decision('READY','Operator clears stop','Await explicit resume','Hold position')
        elif req.action=='PAUSE':
            state.data['scenario']['playing']=False;sim.recovering=False
            sim.decision('WAITING FOR OPERATOR','Pause autonomy','Hold position','Await resume');r['velocity_linear']=0
        elif req.action=='RESUME':sim.act('NORMAL_MISSION')
        elif req.action=='NAVIGATE_TO':
            r['current_goal']=req.goal.model_dump();state.data['map']['planned']=[dict(r['position']),req.goal.model_dump()]
            sim.decision('NAVIGATING','Operator goal','Navigate to requested point','Demo goal active')
        else:
            if req.action=='DEPLOY_RELAY' and r['relay_nodes_remaining']==0:raise HTTPException(409,'No relay nodes remaining')
            sim.act(req.action)
    state.emit('command.requested',req.model_dump(),'BASE');state.log('SYSTEM','Operator: '+req.action+' • '+state.data['data_mode']);await broadcast()
    return {'accepted':True,'execution':'SIMULATED' if state.data['data_mode']=='DEMO' else 'LOCAL_ACK'}
@app.post('/api/missions/start')
async def start():
    state.reset(state.data['data_mode']);sim.reset();await broadcast();return {'id':state.data['mission_id']}
@app.post('/api/missions/end')
async def end():
    state.data['mission_active']=False;state.data['scenario']['playing']=False
    if state.data['data_mode']=='DEMO':state.data['rover']['velocity_linear']=0
    state.log('SYSTEM','Recording session ended');db.end(state.data['mission_id']);db.save(state.data['mission_id'],state.data);await broadcast()
    return {'ended':True,'note':'Ending recording does not stop real R01'}
@app.get('/api/missions')
def missions():return db.missions()
@app.get('/api/missions/{id}')
def mission(id:str):
    value=db.snapshot(id)
    if not value:raise HTTPException(404,'Snapshot not found')
    return value
@app.get('/api/history')
def history(mission:str|None=None,type:str|None=None,limit:int=500):
    return db.history(mission,type,max(1,min(10000,limit)))
@app.get('/api/export')
def export(mission:str|None=None,format:str='json'):
    rows=db.history(mission,limit=100000)
    if format=='csv':
        out=io.StringIO();w=csv.DictWriter(out,fieldnames=['id','mission','type','timestamp','source','mode','payload']);w.writeheader()
        for row in rows:w.writerow(row|{'payload':json.dumps(row['payload'])})
        return Response(out.getvalue(),media_type='text/csv',headers={'Content-Disposition':'attachment; filename=mission-events.csv'})
    return Response(json.dumps(rows,indent=2),media_type='application/json',headers={'Content-Disposition':'attachment; filename=mission-events.json'})
@app.post('/api/ingest/rover',dependencies=[Depends(real)])
def rover(req:Rover):return put('rover',req.model_dump(),'rover.telemetry')
@app.post('/api/ingest/workers/{worker_id}',dependencies=[Depends(real)])
def worker(worker_id:str,req:Worker):
    if req.worker_id!=worker_id:raise HTTPException(422,'Worker ID mismatch')
    value=req.model_dump()
    if value['sos'] or value['fall']:value['state']='EMERGENCY'
    old=next((w for w in state.data['workers'] if w['worker_id']==worker_id),None)
    state.data['workers']=[w for w in state.data['workers'] if w['worker_id']!=worker_id]+[value]
    state.emit('worker.telemetry',value,'WORKERS')
    if value['state']=='EMERGENCY' and (not old or old['state']!='EMERGENCY'):
        zone=Zone(checkpoint=value['last_checkpoint'],start_relay=value['zone_start_relay'],end_relay=value['zone_end_relay']).model_dump()
        id=state.marker('WORKER_ZONE',worker_id+' emergency','CRITICAL',zone=zone)
        state.alert('WORKERS',worker_id+' emergency','CRITICAL',str(zone),id)
    return {'accepted':True}
class LoRaPacket(Model):
    packet:str
    last_checkpoint:str|None=None
    zone_start_relay:str|None=None
    zone_end_relay:str|None=None
    rssi:float|None=None
@app.post('/api/ingest/lora',dependencies=[Depends(real)])
def lora(req:LoRaPacket):
    try:w=LoRaWorkerProvider.parse(req.packet,**req.model_dump(exclude={'packet'}))
    except ValueError as e:raise HTTPException(422,str(e))
    return worker(w.worker_id,w)
@app.post('/api/ingest/environment',dependencies=[Depends(real)])
def environment(req:Environment):
    for name,v in req.readings.items():
        old=state.data['environment'].get(name,{})
        if v.severity in ('WARNING','CRITICAL') and old.get('severity')!=v.severity:
            id=state.marker('GAS_HAZARD',name+' '+v.severity,v.severity)
            state.alert('HAZARDS',name+' '+v.severity,v.severity,marker_id=id)
    return put('environment',{k:v.model_dump() for k,v in req.readings.items()},'environment.telemetry')
@app.post('/api/ingest/thermal',dependencies=[Depends(real)])
def thermal(req:Thermal):return put('thermal',req.model_dump(),'thermal.telemetry')
@app.post('/api/ingest/ai',dependencies=[Depends(real)])
def ai(req:Detection):
    value=req.model_dump();state.data['detections']=[d for d in state.data['detections'] if d['detection_id']!=req.detection_id][-99:]+[value]
    state.emit('ai.detection',value)
    return {'accepted':True}
@app.post('/api/ingest/ai/assessment',dependencies=[Depends(real)])
def assessment(req:Assessment):return put('ai',req.model_dump(),'ai.assessment')
@app.post('/api/ingest/network',dependencies=[Depends(real)])
def network(req:Network):return put('network',req.model_dump(),'network.topology')
@app.post('/api/ingest/video',dependencies=[Depends(real)])
def video(req:Video):return put('video',req.model_dump(),'video.source')
@app.post('/api/ingest/map/pose',dependencies=[Depends(real)])
def pose(req:Vec3):
    if not state.data['rover']:raise HTTPException(409,'Ingest rover telemetry first')
    state.data['rover']['position']=req.model_dump();state.data['rover']['timestamp']=now();state.emit('map.pose',req.model_dump())
    return {'accepted':True}
@app.post('/api/ingest/map/path',dependencies=[Depends(real)])
def path(req:Path):
    state.data['map'][req.kind]=[p.model_dump() for p in req.points];state.emit('navigation.path',req.model_dump())
    return {'accepted':True}
@app.post('/api/ingest/map/markers',dependencies=[Depends(real)])
def marker(req:Marker):
    markers=state.data['map']['markers'];state.data['map']['markers']=[m for m in markers if m['id']!=req.id]+[req.model_dump()]
    state.emit('map.marker',req.model_dump());return {'accepted':True}
@app.post('/api/ingest/map/occupancy',dependencies=[Depends(real)])
def occupancy(req:Occupancy):
    if len(req.cells)!=req.width*req.height or any(v < -1 or v > 100 for v in req.cells):
        raise HTTPException(422,'Expected width × height occupancy cells in [-1,100]')
    state.data['map']['occupancy']=req.model_dump();state.emit('map.occupancy',req.model_dump())
    return {'accepted':True}
@app.post('/api/ingest/map/pointcloud',dependencies=[Depends(real)])
def cloud(req:PointCloud):
    if len(req.xyz)%3:raise HTTPException(422,'xyz must contain complete triples')
    m=state.data['map'];m['cloud']=([] if req.replace else m['cloud'])+req.xyz;m['cloud']=m['cloud'][-300000:];m['explored']=1;m['frame_id']=req.frame_id
    state.cloud_revision+=1
    state.emit('map.pointcloud',{'sequence':req.sequence,'points':len(req.xyz)//3,'frame_id':req.frame_id})
    return {'accepted':True,'retained_points':len(m['cloud'])//3}
@app.post('/api/ingest/map/pointcloud/binary',dependencies=[Depends(real)])
async def binary_cloud(request:Request,sequence:int=0,replace:bool=False):
    raw=await request.body()
    if len(raw)>600000 or len(raw)%12:raise HTTPException(422,'Expected at most 50,000 little-endian float32 XYZ triples')
    return cloud(PointCloud(sequence=sequence,replace=replace,xyz=list(struct.unpack('<'+'f'*(len(raw)//4),raw))))
@app.websocket('/ws/live')
async def live(ws:WebSocket):
    origin=ws.headers.get('origin')
    if origin:
        from urllib.parse import urlparse
        if urlparse(origin).hostname not in ('localhost','127.0.0.1',ws.url.hostname):await ws.close(code=1008);return
    await ws.accept();state.clients.add(ws)
    await ws.send_json(Event(type='system.snapshot',source='BASE',data_mode=state.data['data_mode'],payload=state.snapshot()).model_dump())
    try:
        while True:await ws.receive_text()
    except WebSocketDisconnect:pass
    finally:state.clients.discard(ws)
dist=FilePath(__file__).resolve().parents[2]/'frontend'/'dist'
if dist.exists():
    app.mount('/assets',StaticFiles(directory=dist/'assets'),name='assets')
    @app.get('/{path:path}')
    def spa(path:str):
        if path.startswith(('api/','ws/')):raise HTTPException(404)
        return FileResponse(dist/'index.html')
