import math
from datetime import datetime
from .models import now
from .providers.mock import p
STEPS=['All systems online','R01 begins autonomous exploration','Tunnel reconstruction advances','Wearable telemetry received','Methane warning detected and mapped','R01 reroutes around hazard','Possible person detected','Thermal anomaly corroborates candidate','Victim marker recorded','W04 SOS activated','Last confirmed worker zone highlighted','R2–R3 link fails','Failed segment identified','Autonomous recovery initiated','R01 approaches deployment point','JR-NODE-01 deployed','Wireless bypass established','End-to-end connection validated','Offline mission events synchronized','Rescue mission resumed']
RECOVERY=['Link failure detected','Disconnected segment identified','Recovery location calculated','Navigating to deployment point','JR relay node deployed','Wireless bypass established','Validating end-to-end link','Communication restored']
class Simulation:
    def __init__(self,state): self.s=state; self.reset()
    def reset(self):self.tick_count=0;self.recovering=False;self.recovery_ticks=0
    def decision(self,state,trigger,decision,action,next_check='Continuous safety evaluation'):
        d=self.s.data;d['rover']['mission_state']=state;d['ai'].update(state=state,trigger=trigger,decision=decision,action=action,next_check=next_check);self.s.emit('mission.state',d['ai'])
    def act(self,action):
        d=self.s.data;r=d['rover'];n=d['network']
        if action=='RESET':self.s.reset('DEMO');self.reset();return
        if action=='PLAY':d['scenario']['playing']=True;return
        if action=='PAUSE':d['scenario']['playing']=False;return
        if action=='STEP': self.step();return
        if action=='NORMAL_MISSION':
            if d['stop_latched']:return
            self.decision('AUTONOMOUS EXPLORE','Operator starts demo mission','Inspect eastern passage','Follow planned route')
        elif action=='GAS_LEAK':
            d['environment']['Methane'].update(value=760,severity='WARNING',timestamp=now())
            id=self.s.marker('GAS_HAZARD','Elevated combustible-gas sensor response • demo')
            self.s.alert('HAZARDS','Methane sensor warning • simulated / not calibrated ppm','WARNING',marker_id=id)
            self.decision('HAZARD ASSESSMENT','Gas sensor warning','Stop approach and assess alternative','Hold position')
        elif action=='DETECT_VICTIM':
            pos=p(r['position']['x']+4.6,r['position']['z'])
            det={'detection_id':'PERSON-01','timestamp':now(),'classification':'person','confidence':.91,'bounding_box':[.55,.28,.17,.5],'distance':4.6,'world_position':pos,'thermal_confirmation':True,'severity':'WARNING','status':'ACTIVE','image_reference':None}
            d['detections']=[det];self.s.emit('ai.detection',det)
            d['thermal'].update(values=[27.4+9.4*math.exp(-((i%8-4)**2+(i//8-3)**2)/3) for i in range(64)],interpretation='Possible human heat signature • AI analysis',confidence=.84,timestamp=now())
            id=self.s.marker('VICTIM','Possible victim • AI confidence 91%','WARNING',position=pos)
            self.s.alert('AI','Person candidate with correlated thermal anomaly','WARNING',marker_id=id)
            d['ai']['observations']=['Person confidence 91%','Thermal correlation positive','Range 4.6 m','Path traversable','Gas condition checked before approach']
            safe=d['environment']['Methane']['severity']=='SAFE'
            self.decision('INVESTIGATE VICTIM' if safe else 'HAZARD ASSESSMENT','Person + thermal anomaly','Approach for closer inspection' if safe else 'Hold; gas warning prevents approach','Navigation goal requested' if safe else 'Await safe route','Re-evaluate at 2.0 m')
        elif action in ['WORKER_SOS','WORKER_FALL']:
            w=d['workers'][3];w.update(state='EMERGENCY',sos=action=='WORKER_SOS' or w['sos'],fall=action=='WORKER_FALL' or w['fall'],spo2=89)
            id=self.s.marker('WORKER_ZONE','W04 last confirmed zone','CRITICAL',zone={'start_relay':w['zone_start_relay'],'end_relay':w['zone_end_relay']})
            self.s.alert('WORKERS',f"W04 {'SOS activated' if action=='WORKER_SOS' else 'fall detected'}",'CRITICAL','R3 ↔ R4',id);self.s.emit('worker.emergency',w,'WORKERS')
        elif action=='NETWORK_BREAK':
            n.update(status='DEGRADED',failed_segment='R2 ↔ R3',recovery_step=1,recovery_started=now(),deployment='IDLE')
            for l in n['links']:
                if l['source']=='R2' and l['target']=='R3':l['status']='FAILED'
            r.update(primary_link='LOST',connectivity='DEGRADED',lora_link='ACTIVE')
            id=self.s.marker('NETWORK_BREAK','R2 ↔ R3 broadband break',position=p(22,4))
            self.s.alert('NETWORK','Relay R2–R3 connection lost','WARNING','R2 ↔ R3',id);self.s.emit('network.failure',n)
        elif action=='START_NETWORK_RECOVERY':
            if not n['failed_segment']:self.act('NETWORK_BREAK')
            self.recovering=True;self.recovery_ticks=0
            self.decision('NETWORK RECOVERY','Broadband path lost','Deploy wireless bypass','Calculate reachable deployment point')
        elif action=='DEPLOY_RELAY':
            if r['relay_nodes_remaining']<=0:
                self.recovering=False;self.decision('WAITING FOR OPERATOR','Relay payload exhausted','Cannot deploy bypass','Hold and request operator assistance');self.s.alert('NETWORK','Relay payload exhausted','WARNING');return
            i=n['deployed']+1;id=f'JR-NODE-{i:02}';r['relay_nodes_remaining']-=1;n['deployed']=i
            n.update(deployment='VERIFYING',recovery_step=max(5,n['recovery_step']))
            n['nodes'].append({'id':id,'role':'Bypass relay','position':p(23,4+i),'status':'ONLINE','signal':-59,'latency':12,'last_heartbeat':now()})
            n['links'] += [{'source':'R2','target':id,'status':'HEALTHY','kind':'WIRELESS'},{'source':id,'target':'R3','status':'HEALTHY','kind':'WIRELESS'}]
            self.s.marker('BYPASS_NODE',id,'INFORMATION',position=p(23,4+i));self.s.log('NETWORK',id+' deployed');self.s.emit('relay.deployment',n)
        elif action=='RESTORE_NETWORK':
            bypass=n['deployed']>0 and n['failed_segment'] is not None
            n.update(status='BYPASS ACTIVE' if bypass else 'HEALTHY',recovery_step=8,deployment='ACTIVE' if bypass else 'IDLE')
            if not bypass:
                for link in n['links']:link['status']='HEALTHY'
                n['failed_segment']=None
            r.update(primary_link='CONNECTED',connectivity='CONNECTED',lora_link='STANDBY');self.recovering=False
            self.s.log('NETWORK','End-to-end connection restored; offline events synchronized');self.s.emit('network.recovery',n)
        elif action in ['COMMUNICATION_LOSS','LORA_FALLBACK']:
            r.update(primary_link='LOST',lora_link='ACTIVE' if action=='LORA_FALLBACK' else 'LOST',connectivity='DEGRADED' if action=='LORA_FALLBACK' else 'LOST')
            self.decision('LORA FALLBACK' if action=='LORA_FALLBACK' else 'COMMUNICATION LOST','Link unavailable','R01 applies local configured behavior','Demo policy: hold safely until link restored')
            self.s.alert('NETWORK',action.replace('_',' '),'WARNING')
        elif action=='RETURN_TO_BASE':
            if d['stop_latched']:return
            self.decision('RETURN TO BASE','Operator request','Follow recorded return path','Navigate toward base');d['map']['return_path']=list(reversed(d['map']['trail']))+[p(0,0)]
        self.s.emit('network.topology',n)
    def step(self):
        d=self.s.data;i=d['scenario']['step']
        if i>=len(STEPS):d['scenario']['playing']=False;return
        actions={1:'NORMAL_MISSION',4:'GAS_LEAK',6:'DETECT_VICTIM',9:'WORKER_SOS',11:'NETWORK_BREAK',15:'DEPLOY_RELAY',17:'RESTORE_NETWORK'}
        if i in actions:self.act(actions[i])
        if i==5:
            self.decision('REROUTING','Gas warning zone mapped','Select alternative offset route','Replan navigation')
            d['map']['planned']=[p(8,0),p(14,-1.5),p(24,-1.5),p(24,18),p(48,18)]
        if i==12:d['network']['recovery_step']=2
        if i==13:self.decision('NETWORK RECOVERY','Failed segment identified','Calculate bypass position','Recovery goal selected');d['network']['recovery_step']=3
        if i==14:d['network']['recovery_step']=4;d['rover']['position']=p(22,4)
        if i==16:d['network']['recovery_step']=6
        if i==19:self.decision('INVESTIGATE VICTIM','Bypass validated','Resume rescue supervision','Reassess target and hazards');d['scenario']['playing']=False
        d['scenario'].update(step=i+1,label=STEPS[i]);self.s.log('SYSTEM',STEPS[i])
    def tick(self):
        d=self.s.data
        if d['data_mode']!='DEMO' or not d['mission_active']:return
        self.tick_count+=1;t=self.tick_count;r=d['rover'];n=d['network']
        if d['scenario']['playing'] and t%4==0:self.step()
        if self.recovering and not d['stop_latched']:
            self.recovery_ticks+=1
            if self.recovery_ticks%3==0:
                step=n['recovery_step']
                if step<4:n['recovery_step']+=1
                elif step==4:self.act('DEPLOY_RELAY')
                elif step<7:n['recovery_step']+=1
                else:self.act('RESTORE_NETWORK')
                self.s.log('NETWORK',RECOVERY[min(n['recovery_step']-1,7)])
        if n['recovery_started'] and n['recovery_step']<8:n['recovery_duration']=(datetime.fromisoformat(now())-datetime.fromisoformat(n['recovery_started'])).total_seconds()
        moving=not d['stop_latched'] and r['mission_state'] in ['AUTONOMOUS EXPLORE','NAVIGATING','RETURN TO BASE','REROUTING']
        r['velocity_linear']=.18 if moving else 0
        if moving:
            pos=r['position']
            if r['mission_state']=='NAVIGATING' and r['current_goal']:
                g=r['current_goal'];dx=g['x']-pos['x'];dz=g['z']-pos['z'];distance=math.hypot(dx,dz)
                if distance<.2:
                    pos.update(g);self.decision('READY','Goal reached','Navigation complete','Hold')
                else:
                    pos['x']+=.18*dx/distance;pos['z']+=.18*dz/distance;r['orientation']=math.atan2(dz,dx)
            elif r['mission_state']=='RETURN TO BASE':
                if pos['z']>0:pos['z']=max(0,pos['z']-.18);r['orientation']=-math.pi/2
                else:pos['x']=max(0,pos['x']-.18);r['orientation']=math.pi
                if pos['x']==0 and pos['z']==0:self.decision('READY','Base reached','Mission return complete','Hold')
            elif pos['x']<24:pos['x']+=.18;r['orientation']=0
            elif pos['z']<18:pos['z']+=.18;r['orientation']=math.pi/2
            else:pos['x']=min(48,pos['x']+.18);r['orientation']=0
            if t%2==0:d['map']['trail']=(d['map']['trail']+[dict(pos)])[-1000:]
            r['battery']=max(0,r['battery']-.001);d['map']['explored']=min(1,d['map']['explored']+.002)
        r['timestamp']=now();r['distance_to_goal']=round(math.hypot(48-r['position']['x'],18-r['position']['z']),1)
        r['health']['CPU %']=round(43+8*math.sin(t/6),1)
        for i,w in enumerate(d['workers']):
            w['last_seen']=now();w['heart_rate']=round(80+i+4*math.sin(t/8+i));w['temperature']=round(28+i/10+.2*math.sin(t/9),1)
            if t%5==0:self.s.emit('worker.telemetry',w,'WORKERS')
        for val in d['environment'].values():val['timestamp']=now()
        d['thermal']['timestamp']=now();d['video']['timestamp']=now()
        for node in n['nodes']:node['last_heartbeat']=now()
        if t%5==0:
            self.s.emit('rover.telemetry',r);self.s.emit('environment.telemetry',d['environment']);self.s.emit('system.health',r['health'])
