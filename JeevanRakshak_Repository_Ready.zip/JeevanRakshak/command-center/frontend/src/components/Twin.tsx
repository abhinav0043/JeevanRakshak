import {Canvas,useThree} from '@react-three/fiber';
import {OrbitControls,Line,Html,Grid} from '@react-three/drei';
import {useEffect,useMemo,useRef,useState,Suspense,Component,ReactNode} from 'react';
import * as THREE from 'three';
import type {State,Vec} from '../types';
import {Maximize2,RotateCcw,Layers,Focus} from 'lucide-react';
const tuple=(p:Vec,y=0):[number,number,number]=>[p.x,p.y+y,p.z];
const color=(type:string)=>type==='VICTIM'?'#fb7185':type==='GAS_HAZARD'?'#fbbf24':type==='BYPASS_NODE'?'#60a5fa':type==='NETWORK_BREAK'?'#f87171':'#94a3b8';
class Boundary extends Component<{children:ReactNode;fallback:ReactNode},{failed:boolean}>{
 state={failed:false};static getDerivedStateFromError(){return {failed:true};}render(){return this.state.failed?this.props.fallback:this.props.children;}
}
function Cloud({data,explored}:{data:number[];explored:number}){
 const geometry=useMemo(()=>{const g=new THREE.BufferGeometry();g.setAttribute('position',new THREE.BufferAttribute(new Float32Array(300000),3));return g;},[]);
 useEffect(()=>{const a=geometry.getAttribute('position') as THREE.BufferAttribute;a.array.set(data.slice(0,300000));a.needsUpdate=true;geometry.setDrawRange(0,Math.floor(Math.min(data.length/3,100000)*explored));geometry.computeBoundingSphere();},[data,explored,geometry]);
 useEffect(()=>()=>geometry.dispose(),[geometry]);
 return <points geometry={geometry} frustumCulled={false}><pointsMaterial color="#719d96" size={.065} transparent opacity={.68}/></points>;
}
function Camera({view,pose,focus,controls}:{view:string;pose:Vec;focus:Vec|null;controls:React.RefObject<any>}){
 const {camera}=useThree();
 useEffect(()=>{const target=focus??pose;
 if(view==='Follow'){camera.position.set(target.x-9,10,target.z+12);controls.current?.target.set(target.x,0,target.z);}
 else if(view==='Rover'){camera.position.set(target.x-1,1.8,target.z);controls.current?.target.set(target.x+8,1.6,target.z);}
 else if(focus){camera.position.set(target.x+8,18,target.z+14);controls.current?.target.set(target.x,0,target.z);}
 else {camera.position.set(view==='Top'?24:48,view==='Top'?65:40,view==='Top'?8:52);controls.current?.target.set(24,0,7);}
 controls.current?.update();
 },[view,focus,view==='Follow'||view==='Rover'?pose.x:0,view==='Follow'||view==='Rover'?pose.z:0,camera]);
 return null;
}
function Scene({s,view,focus}:{s:State;view:string;focus:Vec|null}){
 const controls=useRef<any>(null),pose=s.rover?.position??{x:0,y:0,z:0};
 const segments=useMemo(()=>s.map.tunnels.flatMap(t=>t.slice(1).map((b,i)=>({a:t[i],b}))),[JSON.stringify(s.map.tunnels)]);
 return <>
 <color attach="background" args={['#0b1418']}/><fog attach="fog" args={['#0b1418',70,150]}/>
 <ambientLight intensity={.9}/><directionalLight position={[10,30,20]} intensity={1.4}/>
 <Grid args={[100,80]} position={[24,-.1,6]} cellSize={1} sectionSize={5} cellColor="#203039" sectionColor="#31434b" fadeDistance={90} infiniteGrid/>
 {segments.map(({a,b},i)=>{const dx=b.x-a.x,dz=b.z-a.z,len=Math.hypot(dx,dz),heading=-Math.atan2(dz,dx);return <group key={i} position={[(a.x+b.x)/2,0,(a.z+b.z)/2]} rotation={[0,heading,0]}>
 <mesh position={[0,-.01,0]}><boxGeometry args={[len+2,.16,4]}/><meshStandardMaterial color="#253536"/></mesh>
 {[-2,2].map(z=><mesh key={z} position={[0,1.2,z]}><boxGeometry args={[len,.08,.08]}/><meshStandardMaterial color="#52716a"/></mesh>)}
 {Array.from({length:Math.floor(len/3)+1},(_,j)=><group key={j} position={[-len/2+j*3,0,0]}>{[-2,2].map(z=><mesh key={z} position={[0,1.6,z]}><boxGeometry args={[.12,3.2,.12]}/><meshStandardMaterial color="#3b5551"/></mesh>)}<mesh position={[0,3.2,0]}><boxGeometry args={[.12,.12,4.1]}/><meshStandardMaterial color="#3b5551"/></mesh></group>)}
 </group>;})}
 <Cloud data={s.map.cloud} explored={s.map.explored}/>
 {s.map.planned.length>1&&<Line points={s.map.planned.map(p=>tuple(p,.18))} color="#58bded" lineWidth={2} dashed dashSize={.7} gapSize={.45}/>}
 {s.map.trail.length>1&&<Line points={s.map.trail.map(p=>tuple(p,.2))} color="#6ee7b7" lineWidth={3}/>}
 {s.map.return_path.length>1&&<Line points={s.map.return_path.map(p=>tuple(p,.25))} color="#c4b5fd" lineWidth={2}/>}
 {s.map.frontier.map((p,i)=><group key={i} position={tuple(p,.3)}><mesh rotation={[-Math.PI/2,0,0]}><ringGeometry args={[1,1.2,32]}/><meshBasicMaterial color="#58bded"/></mesh><Html distanceFactor={45} position={[0,1,0]} center><span className="map-label">FRONTIER F-07</span></Html></group>)}
 {s.network?.nodes.filter(n=>n.id!=='R01').map(n=><group key={n.id} position={tuple(n.position,.5)}><mesh><boxGeometry args={[.55,1,.55]}/><meshStandardMaterial color={n.id.startsWith('JR')?'#60a5fa':'#6ee7b7'}/></mesh><Html distanceFactor={48} position={[0,1,0]} center><span className="map-label">{n.id}</span></Html></group>)}
 {s.map.markers.filter(m=>m.position).map(m=><group key={m.id} position={tuple(m.position!,1)}><mesh><octahedronGeometry args={[.65]}/><meshStandardMaterial color={color(m.type)} emissive={color(m.type)} emissiveIntensity={.2}/></mesh><Html position={[0,1.4,0]} distanceFactor={48} center><span className="map-label" style={{borderColor:color(m.type)}}>{m.type.replaceAll('_',' ')}</span></Html></group>)}
 {focus&&<mesh position={tuple(focus,.1)} rotation={[-Math.PI/2,0,0]}><ringGeometry args={[2.5,2.7,40]}/><meshBasicMaterial color="#f87171" transparent opacity={.7}/></mesh>}
 {s.rover&&<group position={tuple(pose,.5)} rotation={[0,-s.rover.orientation,0]}><mesh><boxGeometry args={[1.15,.5,.8]}/><meshStandardMaterial color="#efbe66"/></mesh>{[-.45,.45].flatMap(x=>[-.5,.5].map(z=><mesh key={x+','+z} position={[x,-.16,z]} rotation={[Math.PI/2,0,0]}><cylinderGeometry args={[.23,.23,.2,12]}/><meshStandardMaterial color="#131c1f"/></mesh>))}<mesh position={[.8,.1,0]} rotation={[0,0,-Math.PI/2]}><coneGeometry args={[.25,.6,3]}/><meshBasicMaterial color="#fcd78e"/></mesh><Html position={[0,1.5,0]} distanceFactor={40} center><b className="map-label rover-label">R01</b></Html></group>}
 <OrbitControls ref={controls} makeDefault maxPolarAngle={Math.PI/2.02} minDistance={2} maxDistance={100}/>
 <Camera view={view} pose={pose} focus={focus} controls={controls}/>
 </>;
}
export function Tactical({s,focus}:{s:State;focus:Vec|null}){
 const occupancy=s.map.occupancy;
 const cells=useMemo(()=>occupancy?occupancy.cells.map((v,i)=>v>50?'M'+((occupancy.origin.x+(i%occupancy.width)*occupancy.resolution)*12+45)+' '+((occupancy.origin.z+Math.floor(i/occupancy.width)*occupancy.resolution)*12+175)+'h'+(occupancy.resolution*12)+'v'+(occupancy.resolution*12)+'h'+(-occupancy.resolution*12)+'z':'').join(' '):'',[occupancy]);
 const projected=useMemo(()=>{const points:Vec[]=[];const stride=Math.max(1,Math.floor(s.map.cloud.length/4500))*3;for(let i=0;i<s.map.cloud.length;i+=stride)points.push({x:s.map.cloud[i],y:0,z:s.map.cloud[i+2]});return points;},[s.map.cloud]);
 const line=(points:Vec[])=>points.map(p=>(p.x*12+45)+','+(p.z*12+175)).join(' ');
 return <svg viewBox="0 0 690 440" className="tactical" aria-label="2D mine tactical map">
 <defs><pattern id="grid" width="24" height="24" patternUnits="userSpaceOnUse"><path d="M24 0H0V24" fill="none" stroke="#26363e" strokeWidth=".5"/></pattern></defs><rect width="690" height="440" fill="url(#grid)"/>
 {cells&&<path d={cells} fill="#758881" opacity=".6"/>}
 {projected.map((p,i)=><circle key={'p'+i} cx={p.x*12+45} cy={p.z*12+175} r=".8" fill="#5d8a7e" opacity=".5"/>)}
 {s.map.frontier.map((p,i)=><circle key={'f'+i} cx={p.x*12+45} cy={p.z*12+175} r="12" fill="none" stroke="#58bded" strokeDasharray="4 3"/>)}
 {s.map.tunnels.map((t,i)=><polyline key={i} points={line(t)} fill="none" stroke="#34484a" strokeWidth="42" strokeLinejoin="round"/>)}
 {s.map.planned.length>0&&<polyline points={line(s.map.planned)} fill="none" stroke="#61b9e7" strokeWidth="2" strokeDasharray="6 6"/>}
 <polyline points={line(s.map.trail)} fill="none" stroke="#6ee7b7" strokeWidth="3"/>
 <polyline points={line(s.map.return_path)} fill="none" stroke="#c4b5fd" strokeWidth="2"/>
 {s.network?.nodes.map(n=><g key={n.id} transform={'translate('+(n.position.x*12+45)+','+(n.position.z*12+175)+')'}><rect x="-5" y="-5" width="10" height="10" fill="#6ee7b7"/><text y="-14" textAnchor="middle">{n.id}</text></g>)}
 {s.map.markers.filter(m=>m.position).map(m=><g key={m.id} transform={'translate('+(m.position!.x*12+45)+','+(m.position!.z*12+175)+')'}><circle r="9" fill={color(m.type)} fillOpacity=".4" stroke={color(m.type)}/><text y="22" textAnchor="middle">{m.type.replaceAll('_',' ')}</text></g>)}
 {focus&&<circle cx={focus.x*12+45} cy={focus.z*12+175} r="36" fill="#fb718533" stroke="#fb7185" strokeDasharray="4 4"/>}
 {s.rover&&<g transform={'translate('+(s.rover.position.x*12+45)+','+(s.rover.position.z*12+175)+') rotate('+(s.rover.orientation*180/Math.PI)+')'}><path d="M12 0L-8 -7L-5 0L-8 7Z" fill="#fbd18a"/></g>}
 <text x="24" y="418">0 ━━━━━ 5 m · MAP FRAME</text>
 </svg>;
}
export function Twin({s,focus=null}:{s:State;focus?:Vec|null}){
 const [view,setView]=useState('Orbit'),[mode,setMode]=useState('3D'),[reset,setReset]=useState(0),ref=useRef<HTMLDivElement>(null);
 return <section className="panel twin" ref={ref}>
 <div className="panel-head"><div><h2><Layers size={16}/> LIVE MINE DIGITAL TWIN</h2><p>LiDAR + depth fusion · SLAM reconstruction · Semantic overlay</p></div><div className="segmented">{['3D','2D'].map(v=><button className={mode===v?'selected':''} key={v} onClick={()=>setMode(v)}>{v}</button>)}<button aria-label="Fullscreen map" onClick={()=>ref.current?.requestFullscreen?.()}><Maximize2 size={14}/></button></div></div>
 <div className="viewer">
 <div className="map-tools">{['Orbit','Top','Follow','Rover'].map(v=><button key={v} onClick={()=>setView(v)} className={view===v?'selected':''}>{v}</button>)}<button aria-label="Reset camera" onClick={()=>{setView('Orbit');setReset(x=>x+1);}}><RotateCcw size={14}/></button></div>
 <div className="map-status"><span className="status-dot"/>{s.data_mode==='DEMO'?'SIMULATED RECONSTRUCTION':s.map.cloud.length?'SENSOR DATA RECEIVED':'WAITING FOR MAP'}</div>
 {mode==='2D'?<Tactical s={s} focus={focus}/>:<Boundary fallback={<Tactical s={s} focus={focus}/>}><Canvas key={reset} camera={{position:[48,40,52],fov:48}} dpr={[1,1.5]}><Suspense fallback={null}><Scene s={s} view={view} focus={focus}/></Suspense></Canvas></Boundary>}
 <div className="map-coordinates"><Focus size={13}/> {s.rover?'R01  X '+s.rover.position.x.toFixed(2)+'  Y '+s.rover.position.y.toFixed(2)+'  Z '+s.rover.position.z.toFixed(2)+' m':'POSE UNAVAILABLE'}<span>GRID 1 m</span></div>
 </div><div className="legend"><span style={{color:'#6ee7b7'}}>━ Travelled</span><span style={{color:'#58bded'}}>┄ Planned</span><span style={{color:'#fbbf24'}}>◆ Hazard</span><span style={{color:'#fb7185'}}>◆ Possible victim</span><span style={{color:'#60a5fa'}}>■ Bypass</span><span>Zones ≠ precise worker positions</span></div>
 </section>;
}
