# Docs

System architecture, setup procedures and test records.

Status: project hardware/source files have not yet been imported. Preserve the working versions when adding them.
